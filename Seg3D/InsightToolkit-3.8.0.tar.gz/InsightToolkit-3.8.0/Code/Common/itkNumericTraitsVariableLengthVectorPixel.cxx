/*=========================================================================

  Program:   Insight Segmentation & Registration Toolkit
  Module:    $RCSfile: itkNumericTraitsVariableLengthVectorPixel.cxx,v $
  Language:  C++
  Date:      $Date: 2007-12-08 17:14:10 $
  Version:   $Revision: 1.2 $

  Copyright (c) Insight Software Consortium. All rights reserved.
  See ITKCopyright.txt or http://www.itk.org/HTML/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even 
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
#include "itkNumericTraitsVariableLengthVectorPixel.h"

namespace itk
{

// All the specializations that were here previously have now been 
// replaced with a single template in the header file.

} // end namespace itk
