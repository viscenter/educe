#include <vnl/vnl_vector.txx>
VNL_VECTOR_INSTANTIATE(signed short);
