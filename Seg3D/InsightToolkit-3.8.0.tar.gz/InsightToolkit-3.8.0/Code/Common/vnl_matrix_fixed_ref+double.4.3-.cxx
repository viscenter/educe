#include <vnl/vnl_matrix_fixed_ref.txx>
VNL_MATRIX_FIXED_REF_INSTANTIATE(double,4,3);
