#include <vnl/algo/vnl_fft_base.txx>
VNL_FFT_BASE_INSTANTIATE(3,float);
