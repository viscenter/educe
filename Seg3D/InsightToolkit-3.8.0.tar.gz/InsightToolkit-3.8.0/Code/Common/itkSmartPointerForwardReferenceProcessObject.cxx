#include "itkSmartPointerForwardReference.h"
#include "itkSmartPointerForwardReference.txx"
#include "itkProcessObject.h"

template class ITKCommon_EXPORT itk::SmartPointerForwardReference<itk::ProcessObject>;




